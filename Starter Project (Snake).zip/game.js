function pesan(){

let teks = "❤️ Terima kasih karena telah hadir dalam hidupku. Mungkin kamu tidak menyadari betapa berharganya dirimu bagiku. Setiap senyum, perhatian, dan kebersamaan yang kita lalui selalu membuat hariku terasa lebih indah. Aku berharap kamu selalu bahagia, sehat, dan dikelilingi oleh hal-hal baik. ❤️";

let i = 0;

document.getElementById("hasil").innerHTML = "";

let ketik = setInterval(function(){

document.getElementById("hasil").innerHTML += teks.charAt(i);

i++;

if(i >= teks.length){
clearInterval(ketik);
}

},40);

}

setInterval(function(){

let hati = document.createElement("div");

hati.innerHTML = "❤️";

hati.classList.add("heart");

hati.style.left = Math.random()*window.innerWidth + "px";

document.body.appendChild(hati);

setTimeout(function(){
hati.remove();
},8000);

},700);